# Write a Python code snippet to print the message "Hello, Python!" to the console.​

# Create a Python program that takes the user's name as input and then prints a personalized greeting.​

# Write a Python program that checks if a given number is positive, negative, or zero, and then prints the corresponding message.​

# Implement a Python loop that prints the first 5 even numbers.​

# Write a Python program that uses a loop to calculate and print the sum of all numbers from 1 to 10.​

# Write a Python function named multiply_numbers that takes two parameters (num1 and num2) and returns their product. Test the function with values 3 and 5.
# Task1
print("Hello python")
# Task2
names=input("Enter  your name")
def greet(name):
    print("My name"+name)
greet(names)
# Task3
num=3
if num>0:
    print("postive")
elif num>0<10:
    print("negative")
else:
    print("zero")
# Task4
for num in  range(100):
 if num%2==0: 
    print(num)
    # Task5
for sums in range(10):
 if sums+1:
   print(sums)
# Task6

def add(a, b):
    print(a * b)


add(3, 5)
